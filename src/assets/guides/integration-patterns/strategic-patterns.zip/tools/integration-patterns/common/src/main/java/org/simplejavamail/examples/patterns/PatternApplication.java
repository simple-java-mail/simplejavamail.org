package org.simplejavamail.examples.patterns;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.simplejavamail.api.SimpleJavaMail;
import org.simplejavamail.api.mailer.Mailer;
import org.simplejavamail.api.mailer.config.TransportStrategy;

/** Starts one local application. Each example connects its own job or workflow framework to the shared mail boundary. */
@SpringBootApplication
@EnableScheduling
public class PatternApplication {
    public static void main(String[] args) {
        SpringApplication.run(PatternApplication.class, args);
    }

    @Bean
    SimpleJavaMail mail() {
        return SimpleJavaMail.fromDefaults();
    }

    @Bean(destroyMethod = "close")
    Mailer mailer(SimpleJavaMail mail, JobStore jobs) {
        // Plain SMTP is deliberate only for this isolated synthetic fixture. Production TLS/credentials belong to deployment configuration.
        return mail.mailerBuilder()
                .withSMTPServer("smtp", 2525)
                .withTransportStrategy(TransportStrategy.SMTP)
                .withSessionTimeout(5000)
                // The terminal outcome also retains acceptance when a later connection cleanup fails.
                .withMailSendResultObserver(jobs::recordMailOutcome)
                .buildMailer();
    }
}
